package com.cake_website_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CakeWebsiteBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
