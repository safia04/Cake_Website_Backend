package com.cake_website_backend.controller;




import com.cake_website_backend.exception.ResourceNotFoundException;
import com.cake_website_backend.model.Product;
import com.cake_website_backend.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/product")
    ResponseEntity<String> saveProduct(@RequestBody Product product){
        String message="";
        try {
            message = productService.saveProduct(product);
        }
        catch(Exception e){
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<String>(message,HttpStatus.OK);
    }

    @GetMapping("/products")
    ResponseEntity<List<Product>> getAllProducts(){
        List<Product> productList=productService.getProducts();
        return ResponseEntity.ok().body(productList);
    }

    @GetMapping("product/{productId}")
    ResponseEntity<?> getProductById(@PathVariable long productId){
        Product existProduct;
        try{
            existProduct=productService.getProductById(productId);
        }catch (ResourceNotFoundException e){
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
        }

        return ResponseEntity.ok().body(existProduct);
    }

    @PutMapping("/product")
    ResponseEntity<?> updateProduct(@RequestBody Product product){
        Product updatedProduct;
        try{
            updatedProduct=productService.updateProduct(product);
        }catch(ResourceNotFoundException e){
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
        }

        return ResponseEntity.ok().body(updatedProduct);
    }

    @DeleteMapping("/product/{productId}")
    ResponseEntity<String> deleteProduct(@PathVariable long productId){
        String message="";
        try{
            message=productService.deleteProduct(productId);
        }catch(ResourceNotFoundException e){
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
        }

        return ResponseEntity.ok().body(message);
    }





}

