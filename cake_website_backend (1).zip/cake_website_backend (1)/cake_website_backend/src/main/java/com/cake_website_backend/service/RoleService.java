package com.cake_website_backend.service;


import com.cake_website_backend.model.Role;

public interface RoleService {
    Role findByName(String name);
}
