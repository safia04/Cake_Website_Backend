package com.cake_website_backend.service.impl;


import com.cake_website_backend.dao.RoleDao;
import com.cake_website_backend.model.Role;
import com.cake_website_backend.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "roleService")
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleDao roleDao;

    @Override
    public Role findByName(String name) {
        Role role = roleDao.findByName(name);
        return role;
    }
}
