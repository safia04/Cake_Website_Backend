package com.cake_website_backend.service;

import com.cake_website_backend.model.Product;

import java.util.List;

public interface ProductService {
    String saveProduct(Product product);

    List<Product> getProducts();

    Product getProductById(long id);

    Product updateProduct(Product product);

    String deleteProduct(long id);
}

