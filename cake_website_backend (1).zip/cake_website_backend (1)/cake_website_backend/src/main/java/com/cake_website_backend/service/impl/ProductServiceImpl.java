package com.cake_website_backend.service.impl;

import com.cake_website_backend.dao.ProductDao;
import com.cake_website_backend.exception.ResourceNotFoundException;
import com.cake_website_backend.model.Product;
import com.cake_website_backend.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    public ProductDao productDao;

    @Override
    public String saveProduct(Product product) {
        if(productDao.findById(product.getProductId()).isPresent()) {
            throw new ResourceNotFoundException("Oops! It seems like the product you're referring to already exists in our records.");
        }
        productDao.save(product);
        return "Success! The product has been added to the database successfully.";
    }

    @Override
    public List<Product> getProducts() {
        return productDao.findAll();
    }

    @Override
    public Product getProductById(long id) {
        Optional<Product> existingProduct=productDao.findById(id);
        if(existingProduct.isPresent()){
            Product existProduct=existingProduct.get();
            return existProduct;
        }
        else{
            throw new ResourceNotFoundException("Oops! We couldn't find any records matching the provided product ID:"+id+"\nPlease double-check the ID and try again.");
        }
    }

    @Override
    public Product updateProduct(Product product) {
        Optional<Product> existingProduct=productDao.findById(product.getProductId());
        if(existingProduct.isPresent()){
            Product existProduct=existingProduct.get();

            existProduct.setDescription(product.getDescription());
            existProduct.setName(product.getName());
            existProduct.setPrice(product.getPrice());
            existProduct.setWeight(product.getWeight());
            existProduct.setImageUrl(product.getImageUrl());

            return productDao.save(existProduct);
        }
        else{
            throw new ResourceNotFoundException("Oops! We couldn't find any records matching the provided product ID:"+product.getProductId()+"\nPlease double-check the ID and try again.");
        }
    }

    @Override
    public String deleteProduct(long id) {
        Optional<Product> existingProduct=productDao.findById(id);
        if(existingProduct.isPresent()){
            Product existProduct=existingProduct.get();
            productDao.delete(existProduct);
            return "Success! The product with ID : "+id+" has been successfully deleted from our records.";
        }
        else{
            throw new ResourceNotFoundException("Oops! We couldn't find any records matching the provided product ID:"+id+"\nPlease double-check the ID and try again.");
        }
    }
}
