package com.cake_website_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CakeWebsiteBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CakeWebsiteBackendApplication.class, args);
	}

}
